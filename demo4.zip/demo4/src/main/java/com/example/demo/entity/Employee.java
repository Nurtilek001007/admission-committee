package com.example.demo.entity;


import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotEmpty(message = "name doesn't must be null!")
    @NotBlank(message = "don't use any space!")
    @Size(min = 2, message = "name must be minimum 2 symbols!")
    @Column(name = "name")
    private String name;

    @NotEmpty(message = "name doesn't must be null!")
    @NotBlank(message = "don't use any space!")
    @Size(min = 2, message = "name must be minimum 2 symbols!")
    @Column(name = "surname")
    private String surname;

    @Column(name = "department")
    private String department;

    @Min(value = 500, message = "must be GREATER than 499")
    @Max(value = 1000, message = "must be LESS than 1001")
    @Column(name = "salary")
    private int salary;

    public Employee() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", department='" + department + '\'' +
                ", salary=" + salary +
                '}';
    }
}
