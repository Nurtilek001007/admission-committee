package com.example.demo.dao;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Student;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Component
@Repository
public class StudentDAOImpl implements StudentDAO{
    @Autowired
    private EntityManager entityManager;

    @Override
    public List<Student> getAllStudents() {
        Session session = entityManager.unwrap(Session.class);

        Query<Student> query = session.createQuery("from Student", Student.class);
        List<Student> allStudents = query.getResultList();
        return allStudents;
    }

    @Override
    public void saveStudent(Student student) {

        Session session = entityManager.unwrap(Session.class);
        session.saveOrUpdate(student);
    }

    @Override
    public Student getStudent(int id) {
        Session session = entityManager.unwrap(Session.class);
        Student student = session.get(Student.class, id);
        return student;
    }

    @Override
    public void deleteStudent(int id) {
        Session session = entityManager.unwrap(Session.class);
        Query<Employee> query = session.createQuery("delete from Student " +
                "where id =:studentId");
        query.setParameter("studentId", id);
        query.executeUpdate();
    }
}
