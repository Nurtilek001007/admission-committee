package com.example.demo.service;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Student;

import java.util.List;

public interface StudentService {
    public List<Student> getAllStudents();

    public void saveStudent(Student employee);

    public Student getStudent(int id);

    public void deleteStudent(int id);
}
