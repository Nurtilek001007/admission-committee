package com.example.demo.controller;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.io.FileNotFoundException;
import java.util.List;

@Controller
public class MyController{

    @Autowired
    private MyRestController restController;

    @RequestMapping("/hr_info")
    public String getInfoOnlyForHr(){
        return "/view_for_hr";
    }

    @RequestMapping("/manager_info")
    public String getInfoOnlyForManagers(){
        return "/view_for_managers";
    }

    @RequestMapping("/")
    public String showFirstView(){
        return "first-view";
    }

    @RequestMapping("/askDetails")
    public String askEmployeeDetails(Model model){
        model.addAttribute("employee", new Employee());
        return "ask-emp-details-view";
    }

    Employee employee1 = new Employee();
    @RequestMapping("/showDetails")
    public String showEmpDetails(@Valid @ModelAttribute("employee") Employee emp, BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            return "ask-emp-details-view";
        } else {
            employee1.setId(emp.getId());
            employee1.setName(emp.getName());
            employee1.setSurname(emp.getSurname());
            employee1.setDepartment(emp.getDepartment());
            employee1.setSalary(emp.getSalary());
            return "show-emp-details-view";
        }
    }

    @RequestMapping("/reportForEmployee")
    public String reportForEmployee(){
        String path = "C:\\Users\\user\\Desktop\\reportForEmployeePdf.pdf";
        PdfWriter pdfWriter = null;
        try {
            pdfWriter = new PdfWriter(path);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);
            pdfDocument.addNewPage();
            Document document = new Document (pdfDocument);
            String s = "REPORT\n\n This is my report for this University... My data:\n";
            Paragraph paragraph = new Paragraph(s + employee1.toString());
            document.add(paragraph);
            document.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        restController.addNewEmployee(employee1);
        return "report-Employee-view";
    }



    @RequestMapping("/askDetailsStudent")
    public String askStudentDetails(Model model){
        model.addAttribute("student", new Student());
        return "ask-student-details-view";
    }

    Student student1 = new Student();
    @RequestMapping("/showDetailsStudent")
    public String showStudentDetails(@Valid @ModelAttribute("student") Student student, BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            return "ask-student-details-view";
        } else {
            student1.setId(student.getId());
            student1.setName(student.getName());
            student1.setSurname(student.getSurname());
            student1.setDepartment(student.getDepartment());
            student1.setEmail(student.getEmail());
            student1.setUnt(student.getUnt());
            return "show-student-details-view";
        }
    }

    @RequestMapping("/reportForStudent")
    public String reportForStudent(){
        String path = "C:\\Users\\user\\Desktop\\reportForStudentPdf.pdf";
        PdfWriter pdfWriter = null;
        try {
            pdfWriter = new PdfWriter(path);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);
            pdfDocument.addNewPage();
            Document document = new Document (pdfDocument);
            String s = "REPORT\n\n Please accept me to your university. My name is " + student1.getName()
                    + " " + student1.getSurname() + " My data:\n";
            Paragraph paragraph = new Paragraph(s + student1.toString());
            document.add(paragraph);
            document.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        restController.addNewStudent(student1);
        return "application-view";
    }

    @RequestMapping("/acceptedStudents")
    public String acceptedStudents(){
        String path = "C:\\Users\\user\\Desktop\\reportForAcceptedStudents.pdf";
        PdfWriter pdfWriter = null;
        try {

            int maxi = 1;
            pdfWriter = new PdfWriter(path);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);
            pdfDocument.addNewPage();
            Document document = new Document (pdfDocument);
            List<Student> allStudents = restController.showAllStudents();
            for (int i = 0; i < allStudents.size()-1; i++){
                int max = 0;

                if (allStudents.get(i).getUnt() > max){
                    maxi = allStudents.get(i).getId();
                    max = allStudents.get(i).getUnt();
                }
            }

            Student student2 = allStudents.get(maxi);

            String s = "REPORT\n\n Congrats you accepted to our university. Your name is " + student2.getName()
                    + " " + student2.getSurname() + ". You scored " + student2.getUnt() + " points";

            System.out.println(allStudents.size());
            System.out.println(student2.getId());

            Paragraph paragraph = new Paragraph(s);
            document.add(paragraph);
            document.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return "accepted-student";
    }


}
